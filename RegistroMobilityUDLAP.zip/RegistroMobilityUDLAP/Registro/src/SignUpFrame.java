import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class SignUpFrame extends JFrame {

    public SignUpFrame() {
        setTitle("Registro de Transporte Compartido");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        setLocationRelativeTo(null);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel title = new JLabel("Registro de Usuario", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        add(title, gbc);

        // Nombre y Apellido
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        JTextField firstNameField = new JTextField(12);
        add(firstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Apellido:"), gbc);
        gbc.gridx = 1;
        JTextField lastNameField = new JTextField(12);
        add(lastNameField, gbc);

        // Email o Teléfono
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(new JLabel("Correo electrónico o Teléfono:"), gbc);

        gbc.gridy = 4;
        JTextField emailField = new JTextField(20);
        add(emailField, gbc);

        // Contraseña
        gbc.gridy = 5;
        add(new JLabel("Contraseña:"), gbc);

        gbc.gridy = 6;
        JPasswordField passwordField = new JPasswordField(20);
        add(passwordField, gbc);

        // Tipo de usuario (Pasajero o Conductor)
        gbc.gridy = 7;
        add(new JLabel("Registrarse como:"), gbc);

        gbc.gridy = 8;
        JPanel userTypePanel = new JPanel();
        JRadioButton passengerButton = new JRadioButton("Pasajero");
        JRadioButton driverButton = new JRadioButton("Conductor");
        ButtonGroup userTypeGroup = new ButtonGroup();
        userTypeGroup.add(passengerButton);
        userTypeGroup.add(driverButton);
        userTypePanel.add(passengerButton);
        userTypePanel.add(driverButton);
        add(userTypePanel, gbc);

        // Campo de Placa (solo para conductores)
        gbc.gridy = 9;
        add(new JLabel("Placa del Vehículo:"), gbc);

        gbc.gridy = 10;
        JTextField plateField = new JTextField(10);
        plateField.setEnabled(false);
        add(plateField, gbc);

        driverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                plateField.setEnabled(true);
            }
        });

        passengerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                plateField.setEnabled(false);
                plateField.setText("");
            }
        });

        // Botón de Registro
        gbc.gridy = 11;
        JButton signUpButton = new JButton("Registrarse");
        signUpButton.setBackground(Color.GREEN);
        add(signUpButton, gbc);

        setVisible(true);
    }
}
