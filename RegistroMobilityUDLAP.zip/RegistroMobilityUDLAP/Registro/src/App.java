public class App {
    public static void main(String[] args) {
        // Crear y mostrar la interfaz gráfica
        new LoginFrame();
    }
}