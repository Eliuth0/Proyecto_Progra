
public class Conductor {
    private String nombre;
    private String vehiculo;

    public Conductor(String nombre, String vehiculo) {
        this.nombre = nombre;
        this.vehiculo = vehiculo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getVehiculo() {
        return vehiculo;
    }
}